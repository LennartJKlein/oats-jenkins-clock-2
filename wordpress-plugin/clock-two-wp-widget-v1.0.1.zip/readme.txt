=== CLOCK 2 Widget for Wordpress ===
Contributors: Lennart Klein
Tags: clock2, vuejs, oats, jenkins
Requires at least: 5.5
Tested up to: 5.9
Requires PHP: 7.0
License: GPL2
License URI: https://www.gnu.org/licenses/gpl-2.0.html

Provides a widget that shows your current time on the CLOCK 2

== Installation ==
Simply activate the plugin, go to the widgets, activate the widget and place it in a widget area
